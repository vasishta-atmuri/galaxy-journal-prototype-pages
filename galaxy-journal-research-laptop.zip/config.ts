import {homedir} from 'node:os';
import {resolve,join} from 'node:path';
import {readFileSync} from 'node:fs';
import {z} from 'zod';
import {KnoxIdSchema} from './shared/src/research-contract';
export const dataDirectory=resolve(process.env.JOURNAL_BACKUP_DATA||join(process.env.LOCALAPPDATA||join(homedir(),'.local','share'),'GalaxyJournalResearch'));
const Clients=z.array(z.object({knoxId:KnoxIdSchema,tokenHash:z.string().regex(/^[a-f0-9]{64}$/)}).strict()).refine(rows=>new Set(rows.map(r=>r.knoxId)).size===rows.length);
export function readClients(){try{return Clients.parse(JSON.parse(readFileSync(join(dataDirectory,'clients.json'),'utf8')));}catch(e){if((e as NodeJS.ErrnoException).code==='ENOENT')return [];throw Error('Client configuration is invalid.');}}
