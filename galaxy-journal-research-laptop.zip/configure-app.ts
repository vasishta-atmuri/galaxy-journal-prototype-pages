import {writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {parseBackupServer} from './shared/src/research-backup-config';
const value=process.argv[2];if(!value)throw Error('Usage: npm run configure-app -- https://your-research-server.example (or off)');
const url=value==='off'?null:parseBackupServer({version:1,url:value});
const path=resolve('research-backup-config.json');await writeFile(path,JSON.stringify({version:1,url},null,2)+'\n');
console.log('Configuration written to '+path+'. Upload this file to the root of the existing Galaxy Journal Pages repository. It contains only the server address, no credentials.');
