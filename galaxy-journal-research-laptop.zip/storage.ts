import {createHash} from 'node:crypto';
import {ResearchEnrollment} from './shared/src/research-backup-contract';
import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {ResearchSummary,type Summary} from './shared/src/research-contract';
import type {Cursor,DeltaBatch} from './shared/src/research-sync-contract';
export class RequestError extends Error {constructor(public status:number,message:string,public code?:string){super(message);}}
const content=(s:Summary)=>JSON.stringify({...s,throughDay:0,build:'',...(s.version===3?{snapshotSecond:0,storageErrors:0}:{})});
export class ResearchStorage {
 readonly db:DatabaseSync;
 constructor(directory:string){mkdirSync(directory,{recursive:true});this.db=new DatabaseSync(join(directory,'research.sqlite'));this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS snapshots (epoch TEXT PRIMARY KEY, participant TEXT NOT NULL, revision INTEGER NOT NULL, summary TEXT NOT NULL, received_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS installations (id TEXT PRIMARY KEY, knox_id TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE, blocked INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS enrollment_limits (source TEXT PRIMARY KEY, hour INTEGER NOT NULL, count INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS installation_uploads (id TEXT PRIMARY KEY, last_at INTEGER NOT NULL, day INTEGER NOT NULL, count INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS epoch_owners (epoch TEXT PRIMARY KEY, principal_hash TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS streams (epoch TEXT PRIMARY KEY, revision INTEGER NOT NULL, row_count INTEGER NOT NULL, target_total INTEGER NOT NULL, target_metadata TEXT NOT NULL, published_count INTEGER NOT NULL, metadata TEXT, received_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS stream_rows (epoch TEXT NOT NULL, sequence INTEGER NOT NULL, row_id TEXT NOT NULL, row TEXT NOT NULL, PRIMARY KEY(epoch,sequence), UNIQUE(epoch,row_id));
 CREATE TABLE IF NOT EXISTS sync_requests (id TEXT NOT NULL, kind TEXT NOT NULL, minute INTEGER NOT NULL, minute_count INTEGER NOT NULL, day INTEGER NOT NULL, day_count INTEGER NOT NULL, PRIMARY KEY(id,kind));
`);}
 private own(epoch:string,principal:string){
  const row=this.db.prepare('SELECT principal_hash FROM epoch_owners WHERE epoch=?').get(epoch) as {principal_hash:string}|undefined;
  if(row&&row.principal_hash!==principal)throw new RequestError(403,'Research identity belongs to another installation.');
  this.db.prepare('INSERT OR IGNORE INTO epoch_owners(epoch,principal_hash) VALUES(?,?)').run(epoch,principal);
 }
 cursor(epoch:string,principal:string):Cursor{
  const owner=this.db.prepare('SELECT principal_hash FROM epoch_owners WHERE epoch=?').get(epoch) as {principal_hash:string}|undefined;
  if(owner&&owner.principal_hash!==principal)throw new RequestError(403,'Research identity belongs to another installation.');
  const stream=this.db.prepare('SELECT revision,row_count FROM streams WHERE epoch=?').get(epoch) as {revision:number;row_count:number}|undefined;
  if(stream){const last=this.db.prepare('SELECT row_id FROM stream_rows WHERE epoch=? AND sequence=?').get(epoch,stream.row_count) as {row_id:string}|undefined;return {protocol:'journal-sync-2',epoch,revision:stream.revision,rowCount:stream.row_count,lastId:last?.row_id??null};}
  const old=this.db.prepare('SELECT summary FROM snapshots WHERE epoch=?').get(epoch) as {summary:string}|undefined;
  if(old){const s=ResearchSummary.parse(JSON.parse(old.summary));return {protocol:'journal-sync-2',epoch,revision:s.revision,rowCount:s.rows.length,lastId:s.rows.at(-1)?.id??null};}
  return {protocol:'journal-sync-2',epoch,revision:null,rowCount:0,lastId:null};
 }
 private migrate(s:Summary){
  const {rows,...metadata}=s,text=JSON.stringify(metadata),insert=this.db.prepare('INSERT INTO stream_rows(epoch,sequence,row_id,row) VALUES(?,?,?,?)');
  rows.forEach((r,i)=>insert.run(s.epoch,i+1,r.id,JSON.stringify(r)));
  this.db.prepare('INSERT INTO streams VALUES(?,?,?,?,?,?,?,?)').run(s.epoch,s.revision,rows.length,rows.length,text,rows.length,text,new Date().toISOString());
  this.db.prepare('DELETE FROM snapshots WHERE epoch=?').run(s.epoch);
 }
 acceptDelta(d:DeltaBatch,principal:string):Cursor{
  const s=d.summary,{rows,...metadata}=s,text=JSON.stringify(metadata);
  this.db.exec('BEGIN IMMEDIATE');
  try{
   this.own(s.epoch,principal);
   const old=this.db.prepare('SELECT summary FROM snapshots WHERE epoch=?').get(s.epoch) as {summary:string}|undefined;
   if(old)this.migrate(ResearchSummary.parse(JSON.parse(old.summary)));
   const current=this.cursor(s.epoch,principal);
   const stream=this.db.prepare('SELECT * FROM streams WHERE epoch=?').get(s.epoch) as {target_total:number;target_metadata:string;metadata:string|null;published_count:number}|undefined;
   if(current.revision!==null){
    const prior=ResearchSummary.parse({...JSON.parse(stream!.target_metadata),rows:[]});
    if(prior.participant!==s.participant||s.revision<current.revision||d.totalRows<stream!.target_total||s.dropped<prior.dropped||s.throughDay<prior.throughDay||prior.version===3&&(s.snapshotSecond<prior.snapshotSecond||s.storageErrors<prior.storageErrors))throw new RequestError(409,'Incremental history conflicts with the stored history.');
    if(s.revision===current.revision){
     // Time/coverage can advance without an event revision; event identity cannot.
     if(d.totalRows!==stream!.target_total||content({...s,rows:[]})!==content({...prior,rows:[]} as Summary))throw new RequestError(409,'Conflicting revision.');
    }
   }
   const baseLast=d.base.rowCount?this.db.prepare('SELECT row_id FROM stream_rows WHERE epoch=? AND sequence=?').get(s.epoch,d.base.rowCount) as {row_id:string}|undefined:undefined;
   if(d.base.rowCount>current.rowCount||(baseLast?.row_id??null)!==d.base.lastId||d.base.revision!==current.revision&&d.base.rowCount===current.rowCount)throw new RequestError(409,'Cursor changed. Retry from the server cursor.','cursor_changed');
   // Exact lost-response replays are harmless; conflicting overlap is rejected.
   const insert=this.db.prepare('INSERT INTO stream_rows(epoch,sequence,row_id,row) VALUES(?,?,?,?)');
   for(let i=0;i<rows.length;i++){
    const sequence=d.base.rowCount+i+1,row=rows[i],encoded=JSON.stringify(row);
    if(sequence<=current.rowCount){const prior=this.db.prepare('SELECT row FROM stream_rows WHERE epoch=? AND sequence=?').get(s.epoch,sequence) as {row:string};if(prior.row!==encoded)throw new RequestError(409,'Conflicting event replay.');}
    else {if(this.db.prepare('SELECT 1 FROM stream_rows WHERE epoch=? AND row_id=?').get(s.epoch,row.id))throw new RequestError(409,'Duplicate event identity.');insert.run(s.epoch,sequence,row.id,encoded);}
   }
   const count=Math.max(current.rowCount,d.base.rowCount+rows.length),complete=count===d.totalRows;
   if(!rows.length&&!complete)throw new RequestError(422,'An incomplete batch must contain events.');
   this.db.prepare('INSERT INTO streams VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(epoch) DO UPDATE SET revision=excluded.revision,row_count=excluded.row_count,target_total=excluded.target_total,target_metadata=excluded.target_metadata,published_count=excluded.published_count,metadata=excluded.metadata,received_at=excluded.received_at').run(s.epoch,s.revision,count,d.totalRows,text,complete?count:stream?.published_count??0,complete?text:stream?.metadata??null,new Date().toISOString());
   const ack=this.cursor(s.epoch,principal);this.db.exec('COMMIT');return ack;
  }catch(e){this.db.exec('ROLLBACK');throw e;}
 }
 accept(s:Summary,principalHash?:string){
  s=ResearchSummary.parse(s);
  if(s.rows.some((r,i)=>r.day>s.throughDay||r.sequence!==undefined&&r.sequence!==i+1)||new Set(s.rows.map(r=>r.id)).size!==s.rows.length)throw new RequestError(422,'Invalid event sequence.');
  this.db.exec('BEGIN IMMEDIATE');
  try{
   if(principalHash){
    for(const [table,column,value] of [['epoch_owners','epoch',s.epoch]]){
     const owner=this.db.prepare(`SELECT principal_hash FROM ${table} WHERE ${column}=?`).get(value) as {principal_hash:string}|undefined;
     if(owner&&owner.principal_hash!==principalHash)throw new RequestError(403,'Research identity belongs to another private-network user.');
     this.db.prepare(`INSERT OR IGNORE INTO ${table}(${column},principal_hash) VALUES(?,?)`).run(value,principalHash);
    }
   }
   const stream=this.db.prepare('SELECT target_metadata,row_count FROM streams WHERE epoch=?').get(s.epoch) as {target_metadata:string;row_count:number}|undefined;
   const oldRow=stream?{summary:JSON.stringify({...JSON.parse(stream.target_metadata),rows:this.db.prepare('SELECT row FROM stream_rows WHERE epoch=? ORDER BY sequence').all(s.epoch).map(r=>JSON.parse(r.row as string))})}:this.db.prepare('SELECT summary FROM snapshots WHERE epoch=?').get(s.epoch) as {summary:string}|undefined;
   if(oldRow){
    const old=ResearchSummary.parse(JSON.parse(oldRow.summary));
    if(old.participant!==s.participant)throw new RequestError(409,'Epoch belongs to another identity.');
    if(s.revision<old.revision)throw new RequestError(409,'Stale revision.');
    if(s.revision===old.revision&&content(s)!==content(old))throw new RequestError(409,'Conflicting revision.');
    if(s.revision>old.revision&&(s.rows.length<old.rows.length||old.rows.some((r,i)=>JSON.stringify(r)!==JSON.stringify(s.rows[i]))||s.dropped<old.dropped))throw new RequestError(409,'History must be cumulative.');
    if(s.throughDay<old.throughDay||s.version===3&&old.version===3&&(s.snapshotSecond<old.snapshotSecond||s.storageErrors<old.storageErrors)){
     if(s.revision===old.revision){this.db.exec('COMMIT');return;}
     throw new RequestError(409,'Observation coverage went backwards.');
    }
   }
   if(stream){
    // Compatibility for older APKs after this epoch has adopted incremental sync.
    const insert=this.db.prepare('INSERT INTO stream_rows(epoch,sequence,row_id,row) VALUES(?,?,?,?)');s.rows.slice(stream.row_count).forEach((r,i)=>insert.run(s.epoch,stream.row_count+i+1,r.id,JSON.stringify(r)));
    const {rows,...metadata}=s,text=JSON.stringify(metadata);this.db.prepare('UPDATE streams SET revision=?,row_count=?,target_total=?,target_metadata=?,published_count=?,metadata=?,received_at=? WHERE epoch=?').run(s.revision,rows.length,rows.length,text,rows.length,text,new Date().toISOString(),s.epoch);
   }else this.db.prepare('INSERT INTO snapshots(epoch,participant,revision,summary,received_at) VALUES(?,?,?,?,?) ON CONFLICT(epoch) DO UPDATE SET revision=excluded.revision, summary=excluded.summary, received_at=excluded.received_at').run(s.epoch,s.participant,s.revision,JSON.stringify(s),new Date().toISOString());
   this.db.exec('COMMIT'); // Only the committed FULL-synchronous WAL transaction may be acknowledged.
  }catch(e){this.db.exec('ROLLBACK');throw e;}
 }
 enroll(input:unknown,source:string){
  const e=ResearchEnrollment.parse(input),hash=createHash('sha256').update(e.credential).digest('hex');
  this.db.exec('BEGIN IMMEDIATE');
  try{
   const prior=this.db.prepare('SELECT knox_id, token_hash, blocked FROM installations WHERE id=?').get(e.installation) as {knox_id:string;token_hash:string;blocked:number}|undefined;
   if(prior){if(prior.blocked)throw new RequestError(403,'Installation has been revoked.');if(prior.knox_id!==e.knoxId||prior.token_hash!==hash)throw new RequestError(409,'Installation enrollment conflicts.');}
   else{
    const hour=Math.floor(Date.now()/3600000),rate=this.db.prepare('INSERT INTO enrollment_limits(source,hour,count) VALUES(?,?,1) ON CONFLICT(source) DO UPDATE SET hour=excluded.hour,count=CASE WHEN enrollment_limits.hour=excluded.hour THEN enrollment_limits.count+1 ELSE 1 END WHERE enrollment_limits.hour<>excluded.hour OR enrollment_limits.count<100 RETURNING count').get(source,hour);
    if(!rate)throw new RequestError(429,'Enrollment rate limit reached.');
    const total=this.db.prepare('SELECT COUNT(*) n FROM installations').get() as {n:number};if(total.n>=10000)throw new RequestError(429,'Installation capacity reached.');
    this.db.prepare('INSERT INTO installations(id,knox_id,token_hash) VALUES(?,?,?)').run(e.installation,e.knoxId,hash);
    this.db.prepare('DELETE FROM enrollment_limits WHERE hour<?').run(hour-24);
   }
   this.db.exec('COMMIT');return {protocol:'journal-enroll-1' as const,installation:e.installation};
  }catch(e){this.db.exec('ROLLBACK');throw e;}
 }
 authenticate(tokenHash:string){return this.db.prepare('SELECT id,knox_id,blocked FROM installations WHERE token_hash=?').get(tokenHash) as {id:string;knox_id:string;blocked:number}|undefined;}
 admitSync(id:string,kind:'cursor'|'batch'){
  const second=Math.floor(Date.now()/1000),minute=Math.floor(second/60),day=Math.floor(second/86400);
  const prior=this.db.prepare('SELECT * FROM sync_requests WHERE id=? AND kind=?').get(id,kind) as {minute:number;minute_count:number;day:number;day_count:number}|undefined;
  if(prior?.day===day&&prior.day_count>=2000)return (day+1)*86400-second;
  if(prior?.minute===minute&&prior.minute_count>=(kind==='batch'?60:12))return (minute+1)*60-second;
  this.db.prepare('INSERT INTO sync_requests VALUES(?,?,?,1,?,1) ON CONFLICT(id,kind) DO UPDATE SET minute=excluded.minute,minute_count=CASE WHEN sync_requests.minute=excluded.minute THEN sync_requests.minute_count+1 ELSE 1 END,day=excluded.day,day_count=CASE WHEN sync_requests.day=excluded.day THEN sync_requests.day_count+1 ELSE 1 END').run(id,kind,minute,day);return 0;
 }
 admitUpload(id:string){
  const now=Math.floor(Date.now()/1000);return !!this.db.prepare('INSERT INTO installation_uploads(id,last_at,day,count) VALUES(?,?,?,1) ON CONFLICT(id) DO UPDATE SET last_at=excluded.last_at,day=excluded.day,count=CASE WHEN installation_uploads.day=excluded.day THEN installation_uploads.count+1 ELSE 1 END WHERE installation_uploads.last_at<=excluded.last_at-5 AND (installation_uploads.day<>excluded.day OR installation_uploads.count<2000) RETURNING id').get(id,now,Math.floor(now/86400));
 }

 summaries(){
  const legacy=(this.db.prepare('SELECT summary FROM snapshots').all() as {summary:string}[]).map(r=>ResearchSummary.parse(JSON.parse(r.summary)));
  const incremental=(this.db.prepare('SELECT epoch,metadata,published_count FROM streams WHERE metadata IS NOT NULL').all() as {epoch:string;metadata:string;published_count:number}[]).map(s=>ResearchSummary.parse({...JSON.parse(s.metadata),rows:this.db.prepare('SELECT row FROM stream_rows WHERE epoch=? AND sequence<=? ORDER BY sequence').all(s.epoch,s.published_count).map(r=>JSON.parse(r.row as string))}));
  return [...legacy,...incremental].sort((a,b)=>a.epoch.localeCompare(b.epoch));
 }
 check(){return this.db.prepare('PRAGMA integrity_check').all();}
 close(){this.db.close();}
}
