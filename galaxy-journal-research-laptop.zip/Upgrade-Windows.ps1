# Run from the freshly extracted package after stopping the old Node receiver.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ServerDirectory,
    [string]$DataDirectory
)
$ErrorActionPreference = 'Stop'
$target = (Resolve-Path -LiteralPath $ServerDirectory).Path
$source = $PSScriptRoot
if ($target.TrimEnd('\') -eq $source.TrimEnd('\')) { throw 'Extract the NEW package into a separate folder first; do not overwrite the running installation.' }
$package = Get-Content -Raw -LiteralPath (Join-Path $target 'package.json') | ConvertFrom-Json
if ($package.name -ne 'galaxy-journal-research-laptop') { throw 'ServerDirectory is not an existing Galaxy Journal receiver folder.' }
if (-not $DataDirectory) {
    if ($env:JOURNAL_BACKUP_DATA) { $DataDirectory = $env:JOURNAL_BACKUP_DATA }
    else { $DataDirectory = Join-Path $env:LOCALAPPDATA 'GalaxyJournalResearch' }
}
$data = (Resolve-Path -LiteralPath $DataDirectory).Path
if (-not (Test-Path -LiteralPath (Join-Path $data 'research.sqlite'))) { throw 'Existing research.sqlite was not found. Supply the ORIGINAL data folder with -DataDirectory. Do not start with a new empty database.' }
$listener = New-Object System.Net.Sockets.TcpListener -ArgumentList ([System.Net.IPAddress]::Loopback),8787
try { $listener.Start() } catch { throw 'Port 8787 is still in use. Stop the old Node receiver before upgrading. Leave the Cloudflare tunnel configured as it is.' } finally { $listener.Stop() }
$nodeVersion = & node --version
if ($LASTEXITCODE -ne 0 -or $nodeVersion -notmatch '^v24\.') { throw 'Use Node.js 24 LTS for this receiver.' }
$backup = Join-Path (Join-Path $env:USERPROFILE 'Documents\GalaxyJournalReceiverBackups') ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
Copy-Item -LiteralPath $data -Destination (Join-Path $backup 'data') -Recurse
# Keep the old program separately; node_modules can be reinstalled with npm ci.
$programBackup = Join-Path $backup 'program'
New-Item -ItemType Directory -Path $programBackup | Out-Null
Get-ChildItem -LiteralPath $target -Force | Where-Object { $_.Name -ne 'node_modules' } | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $programBackup -Recurse }
$files = @('README.md','UPGRADE-WINDOWS.md','Upgrade-Windows.ps1','package.json','package-lock.json','server.ts','receiver.ts','storage.ts','config.ts','manage.ts','configure-app.ts')
foreach ($file in $files) { if (-not (Test-Path -LiteralPath (Join-Path $source $file))) { throw "New package is incomplete: $file" } }
foreach ($file in $files) { Copy-Item -LiteralPath (Join-Path $source $file) -Destination (Join-Path $target $file) -Force }
Get-ChildItem -LiteralPath (Join-Path $source 'shared') -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($source.Length + 1)
    $destination = Join-Path $target $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
}
$env:JOURNAL_BACKUP_DATA = $data
Push-Location $target
try {
    & npm.cmd ci
    if ($LASTEXITCODE -ne 0) { throw 'npm ci failed. Keep the backup; do not start the receiver yet.' }
    & npm.cmd run check
    if ($LASTEXITCODE -ne 0) { throw 'Database check failed. Keep the backup and review the error before starting.' }
} finally { Pop-Location }
Write-Host "Upgrade installed. Private stopped-server backup: $backup"
Write-Host "Original data preserved: $data"
Write-Host "Next: Set-Location -LiteralPath '$target'; npm.cmd start"
Write-Host 'Keep the Cloudflare tunnel running; health must show syncProtocol journal-sync-2 before installing the new APK.'
