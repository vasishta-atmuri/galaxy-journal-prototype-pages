import {createServer,type IncomingMessage} from 'node:http';
import {createHash,timingSafeEqual} from 'node:crypto';
import {unpackResearch} from './shared/src/research-bundle';
import {KnoxIdSchema,RESEARCH_MAX_BODY_BYTES} from './shared/src/research-contract';
import {ResearchStorage,RequestError} from './storage';
import {unpackDelta,SyncCursor} from './shared/src/research-sync-contract';
export type Client={knoxId:string;tokenHash:string};
export const tokenHash=(token:string)=>createHash('sha256').update(token).digest('hex');
async function body(req:IncomingMessage,limit=RESEARCH_MAX_BODY_BYTES){
 if(req.headers['content-encoding'])throw new RequestError(415,'Compression is not supported.');
 if(req.headers['content-type']?.split(';')[0]!=='application/json')throw new RequestError(415,'JSON required.');
 const parts:Buffer[]=[];let size=0;for await(const part of req){size+=part.length;if(size>limit)throw new RequestError(413,'Upload too large.');parts.push(part);}return JSON.parse(Buffer.concat(parts).toString('utf8'));
}
export function receiver(storage:ResearchStorage,clients:()=>Client[],origins:Set<string>,options:{automaticEnrollment?:boolean}={}){
 const server=createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type','application/json');
  const origin=req.headers.origin;
  if(origin){if(!origins.has(origin)){res.writeHead(403).end('{"error":"Origin not allowed"}');return;}res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');}
  const respond=(code:number,value:unknown)=>{if(!res.destroyed)res.writeHead(code).end(JSON.stringify(value));};
  if(req.url==='/health'&&req.method==='GET'){respond(200,{ok:true,protocol:'journal-backup-1',...(options.automaticEnrollment?{syncProtocol:'journal-sync-2',deviceMetadata:'device-environment-1'}:{})});return;}
  let path:URL;try{path=new URL(req.url||'/', 'http://localhost');}catch{respond(400,{error:'Invalid path.'});return;}
  const incremental=options.automaticEnrollment&&(path.pathname==='/v2/cursor'||path.pathname==='/v2/batch');
  if(req.url!=='/v1/backup'&&!(options.automaticEnrollment&&req.url==='/v1/enroll')&&!incremental){respond(404,{error:'Not found'});return;}
  if(req.method==='OPTIONS'){
   if(!origin){respond(403,{error:'Origin required'});return;}
   res.setHeader('Access-Control-Allow-Methods','GET, PUT, POST');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Expose-Headers','Retry-After');res.setHeader('Access-Control-Max-Age','600');res.writeHead(204).end();return;
  }
  if(req.url==='/v1/enroll'){
   if(req.method!=='POST'){respond(405,{error:'Method not allowed'});return;}
   try{const input=await body(req,4096),source=tokenHash(String(req.headers['cf-connecting-ip']||req.socket.remoteAddress||'unknown'));respond(200,storage.enroll(input,source));}catch(e){respond(e instanceof RequestError?e.status:400,{error:e instanceof RequestError?e.message:'Invalid enrollment.'});}return;
  }
  res.setHeader('Access-Control-Expose-Headers','Retry-After');
  if(req.method!==(incremental&&path.pathname==='/v2/cursor'?'GET':'PUT')){respond(405,{error:'Method not allowed'});return;}
  let principalHash:string|undefined,client:Client|undefined;
  if(options.automaticEnrollment){
   const token=/^Bearer ([a-f0-9]{64})$/.exec(req.headers.authorization||'')?.[1];
   const installation=token?storage.authenticate(tokenHash(token)):undefined;
   if(!installation){req.resume();respond(401,{error:'Installation authentication required.',code:'installation_unknown'});return;}
   if(installation.blocked){req.resume();respond(403,{error:'Installation has been revoked.',code:'installation_revoked'});return;}
   const retry=incremental?storage.admitSync(installation.id,path.pathname==='/v2/cursor'?'cursor':'batch'):storage.admitUpload(installation.id)?0:60;
   if(retry){req.resume();res.setHeader('Retry-After',String(retry));respond(429,{error:'Upload rate limit reached.'});return;}
   client={knoxId:installation.knox_id,tokenHash:tokenHash(token!)};principalHash=installation.id;
  }else{
   const token=/^Bearer ([a-zA-Z0-9_-]{32,128})$/.exec(req.headers.authorization||'')?.[1],hash=tokenHash(token||'');
   client=token?clients().find(c=>timingSafeEqual(Buffer.from(c.tokenHash,'hex'),Buffer.from(hash,'hex'))):undefined;
   if(!client){req.resume();respond(401,{error:'Unauthorized'});return;}
  }
  if(incremental){
   try{
    if(path.pathname==='/v2/cursor'){
     const epoch=path.searchParams.get('epoch');if(!SyncCursor.shape.epoch.safeParse(epoch).success)throw new RequestError(400,'Invalid epoch.');
     respond(200,storage.cursor(epoch!,principalHash!));return;
    }
    let d;try{d=await unpackDelta(await body(req));}catch(e){if(e instanceof RequestError)throw e;throw new RequestError(422,'Invalid incremental batch.');}
    if(d.summary.participant!==client!.knoxId)throw new RequestError(403,'Identity does not match credential.');
    if(req.aborted||res.destroyed)return;
    respond(200,storage.acceptDelta(d,principalHash!));
   }catch(e){respond(e instanceof RequestError?e.status:503,{error:e instanceof RequestError?e.message:'Batch could not be committed.',...(e instanceof RequestError&&e.code?{code:e.code}:{})});}
   return;
  }
  try{
   const input=await body(req);let s;
   try{s=await unpackResearch(input);if(s.version===1||!KnoxIdSchema.safeParse(s.participant).success)throw Error();}catch{throw new RequestError(422,'Invalid research bundle.');}
   if(client&&s.participant!==client.knoxId)throw new RequestError(403,'Identity does not match credential.');
   if(req.aborted||res.destroyed)return;
   storage.accept(s,principalHash);
   respond(200,{protocol:'journal-backup-1',epoch:s.epoch,revision:s.revision});
  }catch(e){respond(e instanceof RequestError?e.status:e instanceof SyntaxError?400:503,{error:e instanceof RequestError?e.message:'Upload could not be committed.'});}
 });
 server.requestTimeout=30000;server.headersTimeout=15000;server.maxConnections=16;
 return server;
}
