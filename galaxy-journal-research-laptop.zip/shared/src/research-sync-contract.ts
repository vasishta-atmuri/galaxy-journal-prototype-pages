import {z} from 'zod';
import {ResearchRow,ResearchSummary,RESEARCH_CHUNK_ROWS,type Summary} from './research-contract';
export type SyncSummary=Extract<Summary,{version:3}>;
export const SyncCursor=z.object({protocol:z.literal('journal-sync-2'),epoch:z.string().uuid(),revision:z.number().int().nonnegative().nullable(),rowCount:z.number().int().nonnegative(),lastId:z.string().uuid().nullable()}).strict().superRefine((c,ctx)=>{if((c.rowCount===0)!==(c.lastId===null)||c.revision===null&&c.rowCount!==0)ctx.addIssue({code:'custom',message:'Invalid sync cursor.'});});
export type Cursor=z.infer<typeof SyncCursor>;
const Delta=z.object({protocol:z.literal('journal-sync-2'),summary:z.unknown(),totalRows:z.number().int().nonnegative(),base:SyncCursor,rows:z.array(ResearchRow).max(RESEARCH_CHUNK_ROWS),sha256:z.string().regex(/^[a-f0-9]{64}$/)}).strict();
export const rowsHash=async(rows:unknown)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(rows)))),n=>n.toString(16).padStart(2,'0')).join('');
export async function packDelta(summary:SyncSummary,base:Cursor){
 const {rows:part,...metadata}=ResearchSummary.parse({...summary,rows:summary.rows.slice(base.rowCount,base.rowCount+RESEARCH_CHUNK_ROWS)});
 return {protocol:'journal-sync-2' as const,summary:metadata,totalRows:summary.rows.length,base,rows:part,sha256:await rowsHash(part)};
}
export async function unpackDelta(input:unknown){
 const d=Delta.parse(input);if(!d.summary||typeof d.summary!=='object'||Object.hasOwn(d.summary,'rows'))throw Error('Batch metadata must exclude rows.');
 const summary=ResearchSummary.parse({...d.summary as object,rows:d.rows});
 if(summary.version!==3||d.base.epoch!==summary.epoch||d.base.rowCount+d.rows.length>d.totalRows||d.sha256!==await rowsHash(d.rows)||d.rows.some((r,i)=>r.day>summary.throughDay||r.sequence!==undefined&&r.sequence!==d.base.rowCount+i+1))throw Error('Invalid incremental batch.');
 return {...d,summary};
}
export type DeltaBatch=Awaited<ReturnType<typeof unpackDelta>>;

export class ResearchHistoryConflict extends Error {constructor(){super('Server history conflicts with this device.');}}
