import {z} from 'zod';
import type {Summary} from './research-contract';
import {summarizeResearch} from './research-report';
const code=z.string().regex(/^[A-Z0-9-]{1,32}$/);
const outcome=z.enum(['not-at-all','a-little','somewhat','very-well','extremely-well','no-approach','unsure']);
const member=z.object({code,linkage:z.boolean(),knoxIds:z.array(z.string().min(1)).default([]),epochs:z.array(z.string().uuid()).default([]),status:z.enum(['invited','not-installed','installed','stopped','withdrawn','unknown']),habit:z.enum(['current','lapsed','never','unknown']).default('unknown'),device:z.enum(['managed','personal','undecided','unknown']).default('unknown'),primaryJob:z.enum(['keep','understand','progress','reflect','retrieve','explore','other','unknown']).default('unknown')}).strict();
const response=z.object({code,wave:z.enum(['baseline','week4','week8']),submittedDay:z.number().int().nonnegative(),linkage:z.boolean(),outcome:outcome.optional(),contribution:z.enum(['harder','none','a-little','somewhat','a-lot','not-used','unsure']).optional()}).strict();
/** Analyst-only, explicit crosswalk. Never bundled into the app or uploaded. */
export const ResearchIntake=z.object({version:z.literal(1),members:z.array(member),responses:z.array(response)}).strict();
export function joinResearchSurveys(inputs:Summary[],raw:unknown){
 const intake=ResearchIntake.parse(raw),report=summarizeResearch(inputs),claimed=new Set<string>();
 if(new Set(intake.members.map(m=>m.code)).size!==intake.members.length)throw Error('Duplicate roster code.');
 const owners=new Set<string>();for(const m of intake.members.filter(m=>m.linkage)){for(const key of [...m.knoxIds.map(x=>'knox:'+x),...m.epochs.map(x=>'epoch:'+x)]){if(owners.has(key))throw Error('Ambiguous roster crosswalk.');owners.add(key);}}
 const allowedResponses=intake.responses.filter(r=>r.linkage),responses=new Map<string,z.infer<typeof response>>();
 for(const r of allowedResponses){const key=r.code+':'+r.wave;if(responses.has(key))throw Error('Resolve duplicate survey-wave submissions explicitly.');responses.set(key,r);}
 const members=intake.members.map(m=>{
  if(!m.linkage||m.status==='withdrawn')return {code:m.code,status:m.status,linked:false,coverage:'not-linked',waves:[]};
  const cohorts=report.cohorts.filter(c=>!!c.knoxId&&m.knoxIds.includes(c.knoxId)||m.epochs.includes(c.epoch));
  for(const c of cohorts){if(claimed.has(c.epoch))throw Error('An export matches more than one roster member.');claimed.add(c.epoch);}
  const baseline=responses.get(m.code+':baseline');const scale=['not-at-all','a-little','somewhat','very-well','extremely-well'];
  return {code:m.code,status:m.status,linked:true,habit:m.habit,device:m.device,primaryJob:m.primaryJob,coverage:cohorts.length?'export-submitted':'no-export-submitted',epochs:cohorts.map(c=>c.epoch),multipleEpochs:cohorts.length>1,baselineSubmitted:!!baseline,behavior:cohorts.map(c=>({epoch:c.epoch,firstWeek:c.behavior.firstWeek,milestones:c.behavior.milestones,weeks:c.behavior.weeks})),waves:(['week4','week8'] as const).map(wave=>{
   const survey=responses.get(m.code+':'+wave),a=scale.indexOf(baseline?.outcome||''),b=scale.indexOf(survey?.outcome||'');
   return {wave,surveySubmitted:!!survey,submittedDay:survey?.submittedDay,late:survey?survey.submittedDay>(wave==='week4'?34:62):null,outcome:survey?.outcome,contribution:survey?.contribution,pairedDirection:a>=0&&b>=0?(b>a?'higher':b<a?'lower':'same'):'not-comparable',usage:cohorts.map(c=>({epoch:c.epoch,...c.windows[wave]}))};
  })};
 });
 return {members,unmatchedExportEpochs:report.cohorts.filter(c=>!claimed.has(c.epoch)).map(c=>c.epoch),unlinkedSurveyCount:intake.responses.filter(r=>!r.linkage).length,unmatchedSurveyCount:allowedResponses.filter(r=>!intake.members.some(m=>m.code===r.code&&m.linkage&&m.status!=='withdrawn')).length,limitations:'Exact, permissioned roster linkage only. Survey days are relative to enrollment; export days start at the collection epoch. Do not pool those windows or sum overlapping devices. Missing export is unknown usage. Paired ordinal direction is self-report, not a causal effect or clinical score.'};
}
