import {z} from 'zod';
import {KnoxIdSchema} from './research-contract';
export const InstallationCredential=z.object({installation:z.string().uuid(),credential:z.string().regex(/^[a-f0-9]{64}$/)}).strict();
export const ResearchEnrollment=InstallationCredential.extend({protocol:z.literal('journal-enroll-1'),knoxId:KnoxIdSchema}).strict();
export const EnrollmentAck=z.object({protocol:z.literal('journal-enroll-1'),installation:z.string().uuid()}).strict();
export type Installation=z.infer<typeof InstallationCredential>;
