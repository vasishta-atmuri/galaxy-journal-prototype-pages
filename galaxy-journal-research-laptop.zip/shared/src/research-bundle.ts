import {z} from 'zod';
import {RESEARCH_CHUNK_ROWS,ResearchRow,ResearchSummary,type Summary} from './research-contract';
const Bundle=z.object({format:z.literal('journal-research-segments'),version:z.literal(1),summary:z.unknown(),rowCount:z.number().int().nonnegative(),partCount:z.number().int().nonnegative(),parts:z.array(z.object({index:z.number().int().nonnegative(),sha256:z.string().regex(/^[a-f0-9]{64}$/),rows:z.array(ResearchRow).min(1).max(RESEARCH_CHUNK_ROWS)}).strict())}).strict();
const hash=async(rows:unknown)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(rows))))).map(n=>n.toString(16).padStart(2,'0')).join('');
/** One portable file with checksummed bounded parts; exporting never deletes device history. */
export async function packResearch(summary:Summary){const {rows,...metadata}=ResearchSummary.parse(summary),parts=[];for(let i=0;i<rows.length;i+=RESEARCH_CHUNK_ROWS){const part=rows.slice(i,i+RESEARCH_CHUNK_ROWS);parts.push({index:parts.length,sha256:await hash(part),rows:part});}return {format:'journal-research-segments' as const,version:1 as const,summary:metadata,rowCount:rows.length,partCount:parts.length,parts};}
export async function unpackResearch(input:unknown):Promise<Summary>{
 if((input as {format?:string})?.format!=='journal-research-segments')return ResearchSummary.parse(input);
 const b=Bundle.parse(input);if(b.partCount!==b.parts.length||b.parts.some((p,i)=>p.index!==i||i<b.parts.length-1&&p.rows.length!==RESEARCH_CHUNK_ROWS))throw Error('Missing or reordered research segments.');
 for(const p of b.parts)if(p.sha256!==await hash(p.rows))throw Error('A research segment failed its checksum.');
 const rows=b.parts.flatMap(p=>p.rows);if(rows.length!==b.rowCount||new Set(rows.map(r=>r.id)).size!==rows.length)throw Error('Incomplete or duplicate research rows.');
 return ResearchSummary.parse({...b.summary as object,rows});
}
