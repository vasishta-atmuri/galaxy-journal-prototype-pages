import type {behavioralAnalysis} from './research-behavior';
type Cohort={epoch:string;participant:string;behavior:ReturnType<typeof behavioralAnalysis>};
/** Freeze cohort membership at day 7. Never use future/ever-used features to
 * explain earlier retention. Multi-installation identities need adjudication. */
export function retentionCohorts(cohorts:Cohort[]){
 const excluded=cohorts.filter(c=>!c.behavior.firstWeek.eligible||c.participant==='Unlinked'||cohorts.some(other=>other.epoch!==c.epoch&&other.participant===c.participant));
 const eligible=cohorts.filter(c=>!excluded.includes(c));
 const groups=new Map<string,Cohort[]>();
 for(const c of eligible){const w=c.behavior.firstWeek;
  const dimensions={ai:w.aiProvider,mood:w.moodDays?'used':'not-observed',goals:w.goalDays?'used':'not-observed',rereading:w.revisitedPages?'used':'not-observed',themeUnlock:w.themeUnlocks?'used':'not-observed',notificationEntry:w.notificationTapEntries?'observed':'not-observed'};
  for(const [dimension,value] of Object.entries(dimensions)){const key=dimension+':'+value;groups.set(key,[...(groups.get(key)||[]),c]);}
 }
 return {excludedEpochs:excluded.map(c=>c.epoch),groups:[...groups.entries()].map(([key,members])=>({cohort:key,firstWeekMembers:members.length,weeks:Array.from({length:Math.max(...members.map(c=>c.behavior.weeks.length))},(_,index)=>{
  const observable=members.map(c=>c.behavior.weeks[index]).filter(w=>w?.complete&&w.coverage==='complete');
  const opened=observable.filter(w=>(w.foregroundDays||0)>0).length,participated=observable.filter(w=>w.usefulDays>0).length;
  return {week:index+1,eligibleExports:observable.length,unknownOrImmature:members.length-observable.length,opened,participated,openRate:observable.length?opened/observable.length:null,participationRate:observable.length?participated/observable.length:null};
 })})),limitations:'Submitted installations with a fully observed first week only; duplicate participant epochs are excluded until adjudicated. Week 1 describes cohort formation, not a retention comparison. Denominators require a mature, intact export covering that week. Missing exports/immature windows are unknown, never churn. Differences are associations; features and notification taps are self-selected. Late adoption remains in participant-weeks and milestones, without changing the fixed cohort.'};
}
