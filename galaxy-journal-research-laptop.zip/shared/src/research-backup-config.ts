import {z} from 'zod';
/** Published once by the study owner; this file contains no credentials. */
export const BACKUP_CONFIG_URL='https://vasishta-atmuri.github.io/galaxy-journal-prototype-pages/research-backup-config.json';
export const BackupServerConfig=z.object({version:z.literal(1),url:z.string().nullable()}).strict();
export function parseBackupServer(input:unknown){
 const config=BackupServerConfig.parse(input);if(config.url===null)return '';
 const url=new URL(config.url);
 if(url.protocol!=='https:'||url.username||url.password||url.port||url.pathname!=='/'||url.search||url.hash)throw Error('Use the research server HTTPS root address.');
 return url.origin;
}
