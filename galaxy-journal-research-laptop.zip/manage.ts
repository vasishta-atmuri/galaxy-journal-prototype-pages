import {createInterface} from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import {randomBytes} from 'node:crypto';
import {mkdir,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
import {dataDirectory,readClients} from './config';
import {tokenHash} from './receiver';
import {ResearchStorage} from './storage';
import {KnoxIdSchema} from './shared/src/research-contract';
import {packResearch} from './shared/src/research-bundle';
const command=process.argv[2];
if(command==='add-client'){
 const prompt=createInterface({input:stdin,output:stdout});let id:string;try{id=KnoxIdSchema.parse(await prompt.question('Participant Knox ID (case sensitive): '));}finally{prompt.close();}
 const token=randomBytes(32).toString('base64url'),rows=readClients().filter(c=>c.knoxId!==id);rows.push({knoxId:id,tokenHash:tokenHash(token)});
 await mkdir(dataDirectory,{recursive:true});await writeFile(join(dataDirectory,'clients.json'),JSON.stringify(rows,null,2),{mode:0o600});
 console.log('Private backup access code (shown once; paste into phone Settings):\n'+token+'\nRestart the receiver after adding or rotating a code.');
}else if(['export','report','check'].includes(command)){
 const storage=new ResearchStorage(dataDirectory);
 try{
  if(command==='check'){console.log(storage.check());console.log(storage.summaries().length+' stored epochs.');}
  else{
   const directory=resolve('received-reports');await mkdir(directory,{recursive:true});const files:string[]=[];
   // One latest cumulative snapshot per epoch. Never concatenate rows from repeated snapshots.
   for(const s of storage.summaries()){const file=join(directory,s.epoch+'.json');await writeFile(file,JSON.stringify(await packResearch(s)));files.push(file);}
   console.log('Exported '+files.length+' epochs to '+directory);
   if(command==='report'){if(!files.length)throw Error('No research received yet.');const r=spawnSync(process.execPath,['--import','tsx','shared/scripts/research-report.ts',...files],{stdio:'inherit'});if(r.status!==0)process.exitCode=1;}
  }
 }finally{storage.close();}
}else throw Error('Choose add-client, export, report, or check.');
