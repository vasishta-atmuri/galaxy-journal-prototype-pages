# Galaxy Journal automatic analytics receiver

Testers install the APK and enter their Knox ID once during beta onboarding. They do **not** receive access codes, enter server addresses, or install Tailscale/VPN software. The APK generates a random per-installation credential automatically, saves it locally before contacting the receiver, and enrolls it over HTTPS. The server stores only a hash of that credential. Knox ID is a self-reported research identity, not a password or a verified corporate sign-in.

The receiver accepts research metadata only. Journal writing, photos, place names, prompts and diagnostic content are excluded by the shared strict schemas. Mandatory local collection, sealed storage, manual exports and the existing Cloudflare backend remain intact. Upload runs while Journal is foregrounded; closed apps defer it. Acknowledgment never deletes phone history.

**The owner must configure one reachable HTTPS receiver.** An unconfigured laptop or a localhost/LAN address cannot receive automatic uploads from arbitrary tester networks. The supplied APK looks up one owner-managed configuration from the existing Galaxy Journal Pages site. The current published destination is https://research.galaxyjournal.win. If configuration is unavailable, the app preserves its cached destination; records remain local until a durable acknowledgment. This package does not create a tunnel or open firewall/router ports.

The selected setup is this laptop receiver behind a stable Cloudflare Tunnel. Use your own Cloudflare account and a domain active in that account. Cloudflare forwards HTTPS traffic to the receiver; the research SQLite database remains on your laptop. The older Cloudflare Worker/D1 source is separate, prepared only, and is not used or deployed by these instructions. Testers never do tunnel setup.

## Incremental-sync receiver update — October 8, 2026

**Existing Windows installation: follow [UPGRADE-WINDOWS.md](UPGRADE-WINDOWS.md) first.** The helper backs up the stopped database and existing program, replaces program files in place, and checks the preserved data. Same tunnel/hostname/port; no GitHub edits or tester codes. Upgrade the receiver before the new APK; APK 1.0.126 remains compatible with this receiver.

The new APK saves successful enrollment and sends only events after the server's durable cursor, in checksummed batches of at most 500 rows. A five-minute cooldown replaces the two-second/one-minute schedule. There is no idle polling; failed attempts back off from one minute to thirty minutes with jitter and preserve their deadlines across reopening, including longer Retry-After. New/empty/restored server histories are recovered from retained phone data. Reports retain the last complete cumulative snapshot while partial batches are in progress. Health advertises `syncProtocol: journal-sync-2`; v1 upload compatibility is retained. Enrollment retries after unknown registration, never as a way around revocation.

## Current owner setup — October 8, 2026

The owner's Windows laptop is now reachable at **https://research.galaxyjournal.win** through the stable `galaxy-journal` tunnel. Public health, Android-origin enrollment/upload preflights, strict invalid-enrollment rejection and unauthenticated-upload rejection were verified externally. The owner reports using HTTP/2 for the tunnel because QUIC/UDP is blocked on that network. The public app configuration is published with that exact HTTPS root. The current server accepts Android Origin `https://localhost`; the browser Pages origin currently returns 403, so browser uploads require the `JOURNAL_BACKUP_ORIGINS` setting documented below. This verifies routing/configuration, not a real phone's authenticated receipt. Use the corrected public APK 1.0.126 or newer when available. Public 1.0.121 predates syncing, and local 1.0.122/1.0.123 omitted the required connection-policy and browser timer fixes.

No Cloudflare Worker/D1 research backend was deployed. Cloudflare relays traffic to this laptop. The laptop still needs both its receiver and tunnel running; the owner's reported current tunnel startup is manual. The Windows-service setup below is an option, not a claim that it has been installed on this PC.

## Windows: install and run the package

1. Extract `galaxy-journal-research-laptop.zip` to `C:\GalaxyJournalResearchServer`. That folder must directly contain `package.json`, `server.ts`, this README and `shared`.
2. Install the latest **Node.js 24 LTS** Windows installer from [nodejs.org](https://nodejs.org/en/download). Keep Add to PATH. SQLite is bundled with Node; no Python, compiler or separate database is required. Node 24's SQLite API has release-candidate status in its current documentation. These commands were checked on October 7, 2026; interfaces may change.
3. Open a new ordinary PowerShell window and run:

```powershell
node --version
Set-Location C:\GalaxyJournalResearchServer
npm.cmd ci
npm.cmd start
```

The Node version must start with `v24.`. Using `npm.cmd` avoids PowerShell execution-policy problems. Leave the window open. Stop with **Ctrl+C**; restart with `npm.cmd start`. The server is not installed as a boot service. No `add-client` step is needed for automatic enrollment.

4. Check the local listener from a second PowerShell window:

```powershell
Invoke-RestMethod http://127.0.0.1:8787/health
```

Expect `ok : True`, `protocol : journal-backup-1` and `syncProtocol : journal-sync-2`. Health does not prove authenticated receipt. It exposes no participant data.

Node listens only on `127.0.0.1:8787`. An owner-side HTTPS tunnel/proxy must forward the selected public hostname to this listener. Keep the loopback binding: do not expose port 8787 directly or disable Android certificate validation. The tunnel is an internet-facing analytics endpoint and requires owner authorization/configuration. Nothing in this package changes Windows Firewall or a router. Only the owner configures the tunnel; the phone uses ordinary HTTPS and needs no tunnel/VPN client.

The existing Capacitor config uses HTTPS and disables mixed content. A plain LAN HTTP address or a self-signed certificate accepted only in Chrome is insufficient. Use a trusted HTTPS hostname with a valid certificate. For the APK the receiver permits `https://localhost` Origin and the required JSON/Authorization CORS preflight. If using the browser app, set its exact origin before starting:

```powershell
$env:JOURNAL_BACKUP_ORIGINS = 'https://localhost,https://vasishta-atmuri.github.io'
npm.cmd start
```

## Owner: stable Cloudflare Tunnel on Windows

Checked against [Cloudflare's setup guide](https://developers.cloudflare.com/tunnel/get-started/) on October 8, 2026. Dashboard labels may change. These steps have not yet been executed on your PC.

1. Create/sign in to **your own** [Cloudflare account](https://dash.cloudflare.com/). You need a domain active in that account for a stable public application hostname. If you already own a domain, follow [Add a domain](https://developers.cloudflare.com/fundamentals/manage-domains/add-site/) and complete its DNS/nameserver setup; wait for Active status. An account alone does not supply a permanent public hostname. The GitHub Pages `github.io` hostname is not a domain you control for this setup.
2. Start the receiver using the Windows commands above and confirm `http://127.0.0.1:8787/health` works. Leave its window running.
3. In Cloudflare go to **Networking → Tunnels → Create Tunnel**; name it `journal-analytics`. Choose **Windows** and the PC's architecture. Download/install the connector as directed by the dashboard. Open **Command Prompt as administrator** on the PC and run its displayed install/service command. Use the dashboard's real token locally; do not publish that token in GitHub or send it to testers. Cloudflare documents the service command as `cloudflared.exe service install <TUNNEL_TOKEN>`. Continue once connected/Healthy.
4. Select the tunnel → **Routes → Add route → Published application**. Choose a subdomain such as `analytics` and your domain. Set **Service URL** to **`http://127.0.0.1:8787`**, leaving the path unrestricted. Save. If the UI separates type and address, select HTTP and enter `127.0.0.1:8787`. Public phones use HTTPS; this HTTP hop stays on the laptop's loopback interface. Do not add an interactive Cloudflare Access/email login to this API: the APK uses its automatic installation credential and cannot complete a browser login challenge.
5. Open `https://analytics.YOUR-DOMAIN/health`, substituting your actual domain. Expect `ok: true`; then publish that HTTPS root address once using the next section. Verify a real phone upload/last-success time; health alone is not an authenticated upload test.

Keep the same tunnel and hostname after reboot. Installing the connector as a Windows service avoids manually starting the tunnel each time. The Node receiver is currently a separate manually started process: run `npm.cmd start` again after reboot. Full automatic receiver startup is not installed by this package. The laptop must be awake and online with both processes running. Its stable hostname does not require GitHub configuration updates after ordinary restarts.

Cloudflare relays/processes the HTTPS traffic; these instructions do not provision a Cloudflare-hosted research database, Worker, or D1 service. No tester VPN/client setup or router port forwarding is part of this approach.

## Owner: publish the address once

After the HTTPS receiver actually works, create the configuration file in PowerShell. Substitute its real root hostname:

```powershell
Set-Location C:\GalaxyJournalResearchServer
npm.cmd run configure-app -- https://your-research-server.example
```

This writes `research-backup-config.json` containing only the server address, no secret. Upload/replace that file in the root of the existing [Galaxy Journal Pages repository](https://github.com/vasishta-atmuri/galaxy-journal-prototype-pages) using GitHub → Add file → Upload files → Commit. This is the public app-file repository, not the research database. Verify the published file at [the pinned config address](https://vasishta-atmuri.github.io/galaxy-journal-prototype-pages/research-backup-config.json). For corrected APK 1.0.126+, publish the configuration once for this stable hostname; ordinary restarts need no GitHub or APK changes. The APK connection policy explicitly allows `research.galaxyjournal.win` and the pinned Pages origin. Moving the receiver to a different hostname also needs a connection-policy update and a new APK.

On foreground opening, the incremental APK refreshes that pinned HTTPS configuration when its thirty-minute successful-response cache expires; the cache survives reopening, while a failed or interrupted fetch can retry. Valid settings replace the cached destination; offline, missing or invalid config retains the last valid one. An explicit `{"version":1,"url":null}` disables uploading centrally without stopping local research collection. Generate that file with:

```powershell
npm.cmd run configure-app -- off
```

Publish it in the same place. Configuration is checked on foreground opening, not while the app is closed. A phone currently open picks up a changed address on a foreground opening after the configuration cache expires. QA/test journals cannot make upload/config requests.

## Credentials and integrity

There are no user-facing access codes. The client creates a random installation UUID and a 256-bit credential, keeps it in its research-only local store, and automatically posts a small `/v1/enroll` request. Repeated enrollment with the same ID, Knox ID and credential is idempotent, including after a lost response. A different credential/identity cannot take over the existing installation. Uploads require its Bearer credential and matching Knox ID; each epoch is bound to its authenticated installation. Reinstalls create separate epochs/credentials rather than merging observation windows.

Enrollment is open to a caller supplying a valid self-reported Knox ID. It does not prove Samsung/corporate account ownership or that the caller runs an untampered beta APK. CORS is an origin guard, not authentication. A public pilot must treat these identities as claims and protect the endpoint with tunnel/provider rate limits. This package bounds request sizes, timeouts, concurrent connections, enrollment (100 new installations per source/hour, 10,000 total) and legacy uploads (five seconds between requests, 2,000 per installation/day), incremental batches (60/minute and 2,000/day per installation) and cursor checks (12/minute and 2,000/day per installation). Source counters use hashes rather than storing raw network addresses. These are explicit pilot limits, not measured production capacity.

Credentials are excluded from journal archives, research exports and reports. The receiver has no per-request body/header/identity logger. A hosting/tunnel provider may have infrastructure logs. Local application storage and the SQLite database are not encrypted by this package; use private accounts and encrypted disks. The preserved `add-client` utility supports the earlier manual-token protocol in explicit compatibility tests; the production server uses automatic installation enrollment and does not require or consume those manually issued codes.

## Phone verification and retry behavior

After owner setup, install the signed update over the existing APK, preserving data. New users and existing users missing an ID supply Knox ID once. Existing saved IDs are retained. Open Settings → Help shape Journal → Analytics sync; there are no server/code controls. Expect last-success time only after a durable acknowledgment. Use **Retry sync now** for an immediate cursor check and pending incremental batches (a server Retry-After still applies).

With the laptop receiver, the laptop must be awake, Node running, the tunnel connected and internet reachable. Stop Node, make an app action and keep Journal open: status should show retry while local export still works. Close Journal, restart Node, then reopen Journal: retained records should upload. Repeat over mobile data/another Wi-Fi to verify the public endpoint, not just a LAN connection. Verify actual phone receipt rather than trusting a health response.

Checks run on foreground opening, about two seconds after committed research changes, and once per minute while open. Network failures back off from five seconds to at most five minutes. Each enrollment+upload attempt has a 20-second deadline including response bodies. Interrupted requests never install partial snapshots; a lost acknowledgment safely retries the cumulative snapshot. Late responses are fenced after background/destination changes. No Android background worker or scheduling is added.

The existing 12,000,000-byte upload bound remains. Bundles contain checksum-validated 500-row parts in one HTTP request. Larger histories stay local for manual export; this is not resumable multipart transport. Conflicting/stale/noncumulative histories are rejected and retained for review. Identity correction after enrollment may need owner review rather than silently relabeling an earlier person's history.

## Storage, reports, backup and restore

By default data is under:

```powershell
Join-Path $env:LOCALAPPDATA 'GalaxyJournalResearch'
```

The directory contains `research.sqlite` and any SQLite WAL/SHM sidecars. Installation hashes and epochs are stored in that database. SQLite WAL + synchronous FULL commit completes before enrollment/upload acknowledgment. Store it on a local private disk, not a network share or a live OneDrive-synced folder. Hardware that ignores flushes can defeat durability.

To change storage, set the same path before **all** server/management commands:

```powershell
$env:JOURNAL_BACKUP_DATA = 'C:\GalaxyJournalPrivateData'
```

Use these commands to verify/export/report:

```powershell
Set-Location C:\GalaxyJournalResearchServer
npm.cmd run check
npm.cmd run export
npm.cmd run report
Start-Process '.\artifacts\research-report\index.html'
```

`check` should return integrity `ok` and the stored epoch count. `export` writes portable JSON under `received-reports`. `report` runs the existing analytics report generator included from current app source, with one latest cumulative snapshot per epoch; repeated snapshots do not duplicate accounting. HTML/CSV/JSON results are under `artifacts\research-report`. Permissioned survey joining remains available:

```powershell
$reports = @(Get-ChildItem '.\received-reports\*.json' | ForEach-Object { $_.FullName })
node --import tsx shared/scripts/research-report.ts @reports --roster C:\PrivateResearch\roster.json
```

After a database restore, exported JSON from a different database can remain in `received-reports`; verify that wildcard list or use a fresh directory. The management `report` command uses only epochs currently in the database.

For backup, stop Node with Ctrl+C and wait for all report/export/check processes to finish. Copy the **whole data directory**, including any WAL/SHM sidecars. Never copy only a live `research.sqlite`.

```powershell
$source = Join-Path $env:LOCALAPPDATA 'GalaxyJournalResearch'
$backup = Join-Path $env:USERPROFILE ('Documents\GalaxyJournalResearch-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
Copy-Item -LiteralPath $source -Destination $backup -Recurse
```

For stopped-server restore, preserve the current directory before copying a known backup:

```powershell
$target = Join-Path $env:LOCALAPPDATA 'GalaxyJournalResearch'
$restoreFrom = 'C:\PrivateResearch\GalaxyJournalResearch-backup-YYYYMMDD-HHMMSS'
if (Test-Path -LiteralPath $target) { Move-Item -LiteralPath $target -Destination ($target + '-before-restore-' + (Get-Date -Format 'yyyyMMdd-HHmmss')) }
Copy-Item -LiteralPath $restoreFrom -Destination $target -Recurse
Set-Location C:\GalaxyJournalResearchServer
npm.cmd run check
npm.cmd start
```

Replace the placeholder with the real backup folder. If using alternate storage, adjust source/target. The incremental APK checks the server cursor on eligible foreground openings or Retry sync now, detects a missing tail and resends it. It can re-enroll its persisted credential if registration was absent from the older server backup. APK 1.0.126 still needs manual retry after a restore. A newer server snapshot rejects an older/conflicting phone snapshot; keep both for review. This restores laptop analytics, not journal entries onto phones.

## Verification limits and sources

Automated checks and packaging run on a Mac. Actual Windows install/storage/tunnel behavior and physical Android-to-internet HTTPS still require verification. Packaging this ZIP does not deploy a receiver. The owner configured the current endpoint separately; external routing/config checks passed on October 8, but an actual phone receipt still needs confirmation.

[Node 24 SQLite API](https://nodejs.org/download/release/latest-v24.x/docs/api/sqlite.html), [SQLite WAL](https://www.sqlite.org/wal.html), [SQLite synchronous](https://www.sqlite.org/pragma.html#pragma_synchronous), [Capacitor configuration](https://capacitorjs.com/docs/config).
